/*
动态加载分页面到基座页面的公共的函数
设置一个json类型参数
类似如下
{
"url": "footer.html",
"domId": "footer"
}
*/
var loadHtml = function(paramJson){
	$.ajax({
		type:"get",
		url:"./" + paramJson.url, //需要获取的页面内容
		async:true,
		success:function(data){ // data就是读取到的分页面的所有html代码内容
			$("#" + paramJson.domId).html(data) //将获取到的内容放到当前页面的指定的id的块中
		}
	});
}

